const API_BASE_URL = 'https://massgptdeleter.onrender.com';

function setBulkMode(enabled) {
    window.BULK_MODE = enabled;
    chrome.storage.local.set({ bulkMode: enabled });

    const toolbar = document.getElementById('bulk-manager-toolbar');
    if (toolbar) {
        const controls = toolbar.querySelector('.bulk-toolbar-controls');
        if (controls) controls.style.display = enabled ? 'flex' : 'none';
        
        const toggle = document.getElementById('bulk-toggle');
        if (toggle) toggle.checked = enabled;
        // reflect checked state on the label for the custom switch visuals
        if (toggle) {
            const lbl = toggle.closest('.bulk-switch');
            if (lbl) lbl.classList.toggle('bulk-switch-checked', !!enabled);
        }
    }

    document.querySelectorAll('.bulk-checkbox-container')
        .forEach(el => el.style.display = enabled ? 'flex' : 'none');
        
    if (enabled) {
        refreshCheckboxes();
    }
}

function createToolbar() {
    const existing = document.getElementById('bulk-manager-toolbar');
    const sidebarNav = document.querySelector('nav[aria-label="Chat history"]');
    
    if (!sidebarNav) return;
    
    if (existing) {
        if (sidebarNav.firstChild !== existing) {
            sidebarNav.prepend(existing);
        }
        return;
    }

    // Create login modal if not logged in yet
    const prevLoginModal = document.getElementById('bulk-login-modal');
    if (prevLoginModal) prevLoginModal.remove();

    chrome.storage.local.get(['jwtToken'], (result) => {
        if (!result.jwtToken) {
            const loginModal = document.createElement('div');
            loginModal.id = 'bulk-login-modal';
            loginModal.className = 'bulk-modal-overlay';
            loginModal.style.display = 'flex';
            loginModal.innerHTML = `
                <div class="bulk-modal-content">
                    <h2 style="margin-top:0; text-align:center;">Bulk Manager</h2>
                    <div class="bulk-login-tabs">
                        <button class="bulk-tab-btn active" data-tab="login">Login</button>
                        <button class="bulk-tab-btn" data-tab="register">Register</button>
                    </div>
                    
                    <div class="bulk-tab-content" id="login-tab" style="display:block;">
                        <input type="email" id="bulk-login-email" class="bulk-input" placeholder="Email" style="margin-bottom:10px;">
                        <input type="password" id="bulk-login-password" class="bulk-input" placeholder="Password" style="margin-bottom:10px;">
                        <button id="bulk-login-btn" class="bulk-upgrade-btn" style="width:100%; margin-bottom:8px;">Login</button>
                    </div>
                    
                    <div class="bulk-tab-content" id="register-tab" style="display:none;">
                        <input type="email" id="bulk-register-email" class="bulk-input" placeholder="Email" style="margin-bottom:10px;">
                        <input type="password" id="bulk-register-password" class="bulk-input" placeholder="Password" style="margin-bottom:10px;">
                        <input type="password" id="bulk-register-confirm" class="bulk-input" placeholder="Confirm Password" style="margin-bottom:10px;">
                        <button id="bulk-register-btn" class="bulk-upgrade-btn" style="width:100%;">Register</button>
                    </div>
                </div>
            `;
            document.body.appendChild(loginModal);

            // Tab switching
            const tabs = loginModal.querySelectorAll('.bulk-tab-btn');
            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    tabs.forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    
                    loginModal.querySelectorAll('.bulk-tab-content').forEach(content => content.style.display = 'none');
                    const tabId = tab.dataset.tab + '-tab';
                    const tabContent = loginModal.querySelector('#' + tabId);
                    if (tabContent) tabContent.style.display = 'block';
                });
            });

            // Login handler
            const loginBtn = loginModal.querySelector('#bulk-login-btn');
            if (loginBtn) {
                loginBtn.addEventListener('click', async () => {
                    const email = loginModal.querySelector('#bulk-login-email').value;
                    const password = loginModal.querySelector('#bulk-login-password').value;
                    
                    if (!email || !password) {
                        alert('Please enter email and password');
                        return;
                    }
                    
                    loginBtn.disabled = true;
                    loginBtn.textContent = 'Logging in...';
                    
                    try {
                        const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ email, password })
                        });
                        
                        if (!response.ok) {
                            const error = await response.json();
                            throw new Error(error.error || 'Login failed');
                        }
                        
                        const data = await response.json();
                        chrome.storage.local.set({
                            jwtToken: data.token,
                            userId: data.user_id,
                            userEmail: data.email,
                            isPro: data.is_pro,
                            isAdmin: data.is_admin
                        }, () => {
                            loginModal.remove();
                            location.reload();
                        });
                    } catch (error) {
                        alert('Login error: ' + error.message);
                        loginBtn.disabled = false;
                        loginBtn.textContent = 'Login';
                    }
                });
            }

            // Register handler
            const registerBtn = loginModal.querySelector('#bulk-register-btn');
            if (registerBtn) {
                registerBtn.addEventListener('click', async () => {
                    const email = loginModal.querySelector('#bulk-register-email').value;
                    const password = loginModal.querySelector('#bulk-register-password').value;
                    const confirm = loginModal.querySelector('#bulk-register-confirm').value;
                    
                    if (!email || !password || !confirm) {
                        alert('Please fill in all fields');
                        return;
                    }
                    
                    if (password !== confirm) {
                        alert('Passwords do not match');
                        return;
                    }
                    
                    registerBtn.disabled = true;
                    registerBtn.textContent = 'Registering...';
                    
                    try {
                        const response = await fetch(`${API_BASE_URL}/api/auth/register`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ email, password })
                        });
                        
                        if (!response.ok) {
                            const error = await response.json();
                            throw new Error(error.error || 'Registration failed');
                        }
                        
                        const data = await response.json();
                        chrome.storage.local.set({
                            jwtToken: data.token,
                            userId: data.user_id,
                            userEmail: data.email,
                            isPro: data.is_pro,
                            isAdmin: data.is_admin
                        }, () => {
                            loginModal.remove();
                            location.reload();
                        });
                    } catch (error) {
                        alert('Registration error: ' + error.message);
                        registerBtn.disabled = false;
                        registerBtn.textContent = 'Register';
                    }
                });
            }
        }
    });

    const toolbar = document.createElement('div');
    toolbar.id = 'bulk-manager-toolbar';
    toolbar.innerHTML = `
        <div class="bulk-toolbar-header">
            <label class="bulk-switch">
                <input type="checkbox" id="bulk-toggle">
                <span class="bulk-switch-label">Bulk Mode</span>
            </label>
            <div class="bulk-settings">
                <button id="bulk-settings-toggle" class="bulk-gear" aria-label="Bulk settings">⚙</button>
            </div>
        </div>
        <div class="bulk-toolbar-controls" style="display: ${window.BULK_MODE ? 'flex' : 'none'};">
            <span id="bulk-select-count">0 selected</span>
            <span id="bulk-delete-remaining" style="font-size:11px; color:#a0a0a0; margin-left:12px; padding:2px 8px; background:#2a2b32; border-radius:4px;"></span>
            <div class="bulk-toolbar-buttons">
                <button id="bulk-select-all" class="bulk-btn">Select All</button>
                <button id="bulk-archive-btn" class="bulk-btn bulk-btn-archive">Archive</button>
                <button id="bulk-delete-btn" class="bulk-btn bulk-btn-delete">Delete</button>
            </div>
        </div>
        <div id="bulk-progress-bar" style="display:none;">
            <div id="bulk-progress-fill"></div>
        </div>
    `;

    sidebarNav.prepend(toolbar);

    // Create limit reached modal
    const prevModal = document.getElementById('bulk-limit-modal');
    if (prevModal) prevModal.remove();

    const limitModal = document.createElement('div');
    limitModal.id = 'bulk-limit-modal';
    limitModal.className = 'bulk-modal-overlay';
    limitModal.style.display = 'none';
    limitModal.innerHTML = `
        <div class="bulk-modal-content">
            <h3 style="margin-top:0;">Daily Limit Reached</h3>
            <p style="margin:12px 0; font-size:14px;">You've reached the maximum of <strong>10 deletes per day</strong> on the free plan.</p>
            <p style="margin:12px 0; font-size:13px; color:#a0a0a0;">Upgrade to Pro to get unlimited deletes and priority support.</p>
            <div class="bulk-modal-buttons">
                <button class="bulk-modal-btn bulk-modal-btn-yes" id="bulk-modal-upgrade">Upgrade to Pro</button>
                <button class="bulk-modal-btn bulk-modal-btn-no" id="bulk-modal-close">Close</button>
            </div>
        </div>
    `;
    document.body.appendChild(limitModal);

    // Wire modal close buttons
    const closeBtn = limitModal.querySelector('#bulk-modal-close');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => { limitModal.style.display = 'none'; });
    }
    
    const upgradeBtn = limitModal.querySelector('#bulk-modal-upgrade');
    if (upgradeBtn) {
        upgradeBtn.addEventListener('click', () => {
            limitModal.style.display = 'none';
            const settingsToggle = toolbar.querySelector('#bulk-settings-toggle');
            if (settingsToggle) settingsToggle.click(); // Open settings with upgrade visible
        });
    }

    // Close modal when clicking outside
    limitModal.addEventListener('click', (e) => {
        if (e.target === limitModal) limitModal.style.display = 'none';
    });

    // Create a full-screen overlay modal for settings and wire behavior
    // Remove any existing overlay to avoid duplicates
    const prevOverlay = document.getElementById('bulk-settings-overlay');
    if (prevOverlay) prevOverlay.remove();

    const overlay = document.createElement('div');
    overlay.id = 'bulk-settings-overlay';
    overlay.className = 'bulk-settings-overlay';
    overlay.style.display = 'none';
    overlay.innerHTML = `
        <div class="bulk-settings-panel modal">
            <div class="bulk-settings-panel-inner">
                <button class="bulk-settings-close" aria-label="Close">×</button>
                <h3 style="margin-top:0;">Bulk Settings</h3>
                <div class="bulk-settings-section">
                    <label>
                        <input type="checkbox" id="bulk-confirm-delete" data-setting="bulkConfirmDelete">
                        Confirm before Delete
                    </label>
                </div>
                <div class="bulk-settings-section">
                    <label>
                        <input type="checkbox" id="bulk-confirm-archive" data-setting="bulkConfirmArchive">
                        Confirm before Archive
                    </label>
                </div>

                <div class="bulk-settings-section">
                    <h4 style="margin:8px 0 6px 0;">Support & Contact</h4>
                    <div class="bulk-support-email">mohammedyusufnakhuda@gmail.com</div>
                    <div style="margin-top:8px;">
                        <label style="display:block; font-size:13px; margin-bottom:6px;">Message
                        <textarea id="bulk-contact-message" class="bulk-textarea" rows="3" placeholder="Write a short message..."></textarea>
                        </label>
                        <div class="bulk-action-row">
                            <button id="bulk-copy-email" class="bulk-btn">Copy Email</button>
                            <button id="bulk-send-email" class="bulk-btn">Send Email</button>
                        </div>
                    </div>
                </div>

                <div class="bulk-settings-section">
                    <h4 style="margin:8px 0 6px 0;">Pro Features</h4>
                    <div style="font-size:13px; color:#d6d6db; margin-bottom:12px;">Unlimited actions & priority support.</div>
                    <button id="bulk-upgrade-btn" class="bulk-upgrade-btn">Upgrade to Pro</button>
                </div>

                <div class="bulk-settings-section bulk-admin-section" id="bulk-admin-section" style="display:none;">
                    <h4 style="margin:8px 0 6px 0;">Admin Controls</h4>
                    <div style="font-size:13px; color:#d6d6db; margin-bottom:10px;">Grant unlimited delete override by toggling admin access.</div>
                    <input type="email" id="bulk-admin-email" class="bulk-input" placeholder="User email">
                    <label class="bulk-admin-toggle" style="margin-top:10px; display:flex; align-items:center; gap:8px; font-size:13px;">
                        <input type="checkbox" id="bulk-admin-enabled">
                        Set as admin (unlimited deletes)
                    </label>
                    <div class="bulk-action-row" style="margin-top:10px;">
                        <button id="bulk-admin-lookup" class="bulk-btn">Lookup</button>
                        <button id="bulk-admin-save" class="bulk-btn">Apply</button>
                    </div>
                    <div id="bulk-admin-result" class="bulk-admin-result" style="margin-top:10px;"></div>
                </div>

            </div>
        </div>
    `;

    document.body.appendChild(overlay);

    const settingsToggle = toolbar.querySelector('#bulk-settings-toggle');
    const settingsOverlay = document.getElementById('bulk-settings-overlay');
    const panelInner = settingsOverlay.querySelector('.bulk-settings-panel-inner');

    if (settingsToggle && settingsOverlay && panelInner) {
        // Open overlay
        settingsToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            settingsOverlay.style.display = 'flex';

            chrome.storage.local.get(['jwtToken', 'isAdmin'], async (storage) => {
                const adminSection = settingsOverlay.querySelector('#bulk-admin-section');
                if (!adminSection) return;

                if (!storage.jwtToken) {
                    adminSection.style.display = 'none';
                    return;
                }

                try {
                    const profileResponse = await fetch(`${API_BASE_URL}/api/user/profile`, {
                        headers: { 'Authorization': `Bearer ${storage.jwtToken}` }
                    });

                    if (!profileResponse.ok) {
                        adminSection.style.display = storage.isAdmin ? 'block' : 'none';
                        return;
                    }

                    const profileData = await profileResponse.json();
                    const isAdmin = !!profileData.is_admin;
                    chrome.storage.local.set({
                        isAdmin,
                        isPro: !!profileData.is_pro
                    });
                    adminSection.style.display = isAdmin ? 'block' : 'none';
                } catch (err) {
                    adminSection.style.display = storage.isAdmin ? 'block' : 'none';
                }
            });
        });

        // Close on background click
        settingsOverlay.addEventListener('click', (e) => {
            if (e.target === settingsOverlay) settingsOverlay.style.display = 'none';
        });

        // Close button
        const closeBtn = settingsOverlay.querySelector('.bulk-settings-close');
        if (closeBtn) closeBtn.addEventListener('click', () => { settingsOverlay.style.display = 'none'; });

        // Close on Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') settingsOverlay.style.display = 'none';
        });

        // Load saved settings
        try {
            chrome.storage.local.get(['bulkConfirmDelete','bulkConfirmArchive'], res => {
                const del = settingsOverlay.querySelector('#bulk-confirm-delete');
                const arc = settingsOverlay.querySelector('#bulk-confirm-archive');
                if (del) del.checked = !!res.bulkConfirmDelete;
                if (arc) arc.checked = !!res.bulkConfirmArchive;
            });
        } catch (err) { }

        // Persist changes
        settingsOverlay.querySelectorAll('input[data-setting]').forEach(inp => {
            inp.addEventListener('change', () => {
                const key = inp.dataset.setting;
                const val = inp.checked;
                const obj = {}; obj[key] = val;
                try { chrome.storage.local.set(obj); } catch (e) {}
            });
        });

        // Copy email button
        const copyBtn = settingsOverlay.querySelector('#bulk-copy-email');
        if (copyBtn) {
            copyBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const email = (settingsOverlay.querySelector('.bulk-support-email') || {}).textContent || 'placeholder@gmail.com';
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(email).then(() => {
                        const existing = document.querySelector('.bulk-toast'); if (existing) existing.remove();
                        const toast = document.createElement('div'); toast.className = 'bulk-toast'; toast.textContent = 'Email copied to clipboard.'; document.body.appendChild(toast); setTimeout(() => toast.remove(), 1800);
                    }).catch(() => {
                        const existing = document.querySelector('.bulk-toast'); if (existing) existing.remove();
                        const toast = document.createElement('div'); toast.className = 'bulk-toast'; toast.textContent = 'Unable to copy email.'; document.body.appendChild(toast); setTimeout(() => toast.remove(), 1800);
                    });
                } else {
                    // fallback
                    const ta = document.createElement('textarea'); ta.value = email; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch(e){} ta.remove();
                    const existing = document.querySelector('.bulk-toast'); if (existing) existing.remove();
                    const toast = document.createElement('div'); toast.className = 'bulk-toast'; toast.textContent = 'Email copied to clipboard.'; document.body.appendChild(toast); setTimeout(() => toast.remove(), 1800);
                }
            });
        }

        // Send Email button opens Gmail compose with prefilled body (uses fixed from address in body)
        const sendBtn = settingsOverlay.querySelector('#bulk-send-email');
        if (sendBtn) {
            sendBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const fromEmail = 'mohammedyusufnakhuda@gmail.com';
                const to = 'mohammedyusufnakhuda@gmail.com';
                const subject = encodeURIComponent('Bulk Manager Contact');
                const msgVal = (settingsOverlay.querySelector('#bulk-contact-message') || {}).value || '';
                const body = encodeURIComponent('From: ' + fromEmail + '\n\n' + msgVal);
                const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(to)}&su=${subject}&body=${body}`;
                window.open(gmailUrl, '_blank');
            });
        }

        // Upgrade button opens Stripe checkout via backend
        const upgradeBtn = settingsOverlay.querySelector('#bulk-upgrade-btn');
        if (upgradeBtn) {
            upgradeBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                upgradeBtn.disabled = true;
                upgradeBtn.textContent = 'Loading...';
                
                try {
                    const response = await fetch(`${API_BASE_URL}/api/create-checkout-session`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            priceType: 'monthly',
                            userId: 'extension-user',
                            email: 'user@example.com'
                        })
                    });
                    
                    if (!response.ok) {
                        throw new Error('Failed to create checkout session');
                    }
                    
                    const data = await response.json();
                    const sessionId = data.sessionId;
                    
                    if (sessionId) {
                        // Redirect to Stripe checkout
                        window.open(`https://checkout.stripe.com/pay/${sessionId}`, '_blank');
                    } else {
                        throw new Error('No session ID returned');
                    }
                } catch (error) {
                    const existing = document.querySelector('.bulk-toast'); if (existing) existing.remove();
                    const toast = document.createElement('div'); toast.className = 'bulk-toast'; toast.textContent = 'Error: ' + error.message; document.body.appendChild(toast); setTimeout(() => toast.remove(), 2500);
                } finally {
                    upgradeBtn.disabled = false;
                    upgradeBtn.textContent = 'Upgrade to Pro';
                }
            });
        }

        const adminLookupBtn = settingsOverlay.querySelector('#bulk-admin-lookup');
        const adminSaveBtn = settingsOverlay.querySelector('#bulk-admin-save');
        const adminEmailInput = settingsOverlay.querySelector('#bulk-admin-email');
        const adminEnabledInput = settingsOverlay.querySelector('#bulk-admin-enabled');
        const adminResult = settingsOverlay.querySelector('#bulk-admin-result');

        if (adminLookupBtn && adminEmailInput && adminEnabledInput && adminResult) {
            adminLookupBtn.addEventListener('click', () => {
                const email = (adminEmailInput.value || '').trim().toLowerCase();
                if (!email) {
                    adminResult.textContent = 'Enter an email first.';
                    return;
                }

                chrome.storage.local.get(['jwtToken'], async (result) => {
                    if (!result.jwtToken) {
                        adminResult.textContent = 'Missing login token.';
                        return;
                    }

                    adminLookupBtn.disabled = true;
                    adminLookupBtn.textContent = 'Looking up...';

                    try {
                        const response = await fetch(`${API_BASE_URL}/api/admin/user?email=${encodeURIComponent(email)}`, {
                            headers: { 'Authorization': `Bearer ${result.jwtToken}` }
                        });

                        const data = await response.json();
                        if (!response.ok) {
                            throw new Error(data.error || 'Lookup failed');
                        }

                        const targetUser = data.user;
                        adminEnabledInput.checked = !!targetUser.is_admin;
                        adminResult.textContent = `Found ${targetUser.email} | Pro: ${targetUser.is_pro ? 'yes' : 'no'} | Admin: ${targetUser.is_admin ? 'yes' : 'no'}`;
                    } catch (err) {
                        adminResult.textContent = `Lookup error: ${err.message}`;
                    } finally {
                        adminLookupBtn.disabled = false;
                        adminLookupBtn.textContent = 'Lookup';
                    }
                });
            });
        }

        if (adminSaveBtn && adminEmailInput && adminEnabledInput && adminResult) {
            adminSaveBtn.addEventListener('click', () => {
                const email = (adminEmailInput.value || '').trim().toLowerCase();
                if (!email) {
                    adminResult.textContent = 'Enter an email first.';
                    return;
                }

                chrome.storage.local.get(['jwtToken'], async (result) => {
                    if (!result.jwtToken) {
                        adminResult.textContent = 'Missing login token.';
                        return;
                    }

                    adminSaveBtn.disabled = true;
                    adminSaveBtn.textContent = 'Saving...';

                    try {
                        const response = await fetch(`${API_BASE_URL}/api/admin/set-admin`, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'Authorization': `Bearer ${result.jwtToken}`
                            },
                            body: JSON.stringify({
                                email,
                                is_admin: !!adminEnabledInput.checked
                            })
                        });

                        const data = await response.json();
                        if (!response.ok) {
                            throw new Error(data.error || 'Save failed');
                        }

                        adminResult.textContent = `Updated ${data.user.email}: admin=${data.user.is_admin ? 'yes' : 'no'}`;
                    } catch (err) {
                        adminResult.textContent = `Save error: ${err.message}`;
                    } finally {
                        adminSaveBtn.disabled = false;
                        adminSaveBtn.textContent = 'Apply';
                    }
                });
            });
        }
    }

    // Sync the custom switch label class with the input state and listen for manual toggles
    const bulkToggleInput = toolbar.querySelector('#bulk-toggle');
    const bulkToggleLabel = toolbar.querySelector('.bulk-switch');
    if (bulkToggleInput && bulkToggleLabel) {
        const sync = () => bulkToggleLabel.classList.toggle('bulk-switch-checked', !!bulkToggleInput.checked);
        bulkToggleInput.addEventListener('change', (e) => {
            sync();
            // if user toggles, update stored state and UI
            try { window.BulkUI.setBulkMode && window.BulkUI.setBulkMode(bulkToggleInput.checked); } catch (e) {}
        });
        sync();
    }
}

function refreshCheckboxes() {
    document.querySelectorAll('a[data-sidebar-item="true"]').forEach(el => {
        const href = el.getAttribute('href');
        if (!href || !href.startsWith('/c/')) return;
        injectCheckbox(el);
    });
}

function injectCheckbox(chatEl) {
    if (chatEl.dataset.bulkInjected) {
        const container = chatEl.querySelector('.bulk-checkbox-container');
        if (container) container.style.display = window.BULK_MODE ? 'flex' : 'none';
        return;
    }

    const container = document.createElement('div');
    container.className = 'bulk-checkbox-container';
    container.style.display = window.BULK_MODE ? 'flex' : 'none';
    
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'bulk-checkbox';
    
    const chatHref = chatEl.getAttribute('href');
    checkbox.dataset.chatId = chatHref;

    checkbox.addEventListener('click', e => {
        e.stopPropagation();
        updateSelectCount();
    });

    container.appendChild(checkbox);
    chatEl.prepend(container);
    chatEl.dataset.bulkInjected = "1";
}

function updateSelectCount() {
    const count = document.querySelectorAll('.bulk-checkbox:checked').length;
    const countEl = document.getElementById('bulk-select-count');
    if (countEl) countEl.textContent = `${count} selected`;
    updateDeleteCounter();
}

function updateDeleteCounter() {
    const counterEl = document.getElementById('bulk-delete-remaining');
    if (!counterEl) return;
    
    chrome.storage.local.get(['jwtToken', 'isPro', 'isAdmin', 'deleteRemaining'], async (result) => {
        if (!result.jwtToken) {
            counterEl.textContent = 'Not logged in';
            return;
        }
        
        const isPro = result.isPro || false;
        const isAdmin = result.isAdmin || false;
        
        if (isPro || isAdmin) {
            counterEl.textContent = isAdmin ? 'Admin (Unlimited)' : 'Pro (Unlimited)';
            counterEl.style.color = isAdmin ? '#f0b232' : '#10a37f';
        } else {
            // Fetch stats from backend
            try {
                const response = await fetch(`${API_BASE_URL}/api/user/profile`, {
                    headers: { 'Authorization': `Bearer ${result.jwtToken}` }
                });
                
                if (response.ok) {
                    const data = await response.json();
                    chrome.storage.local.set({
                        isPro: !!data.is_pro,
                        isAdmin: !!data.is_admin
                    });
                    const stats = data.delete_stats;
                    if (data.is_pro || data.is_admin || stats.limit === null) {
                        counterEl.textContent = data.is_admin ? 'Admin (Unlimited)' : 'Pro (Unlimited)';
                        counterEl.style.color = data.is_admin ? '#f0b232' : '#10a37f';
                    } else {
                        counterEl.textContent = `Deletes: ${stats.remaining}/${stats.limit}`;
                        counterEl.style.color = stats.remaining <= 3 ? '#d93025' : '#a0a0a0';
                    }
                } else {
                    counterEl.textContent = `Deletes: ${result.deleteRemaining || 10}/10`;
                }
            } catch (err) {
                console.error('Failed to fetch delete stats:', err);
                counterEl.textContent = `Deletes: ${result.deleteRemaining || 10}/10`;
            }
        }
    });
}

function initUI() {
    chrome.storage.local.get(["bulkMode"], (res) => {
        window.BULK_MODE = !!res.bulkMode;
        
        const bodyObserver = new MutationObserver(() => {
            const sidebarNav = document.querySelector('nav[aria-label="Chat history"]');
            if (sidebarNav) {
                createToolbar();
                refreshCheckboxes();
                updateDeleteCounter();
                
                if (!window._sidebarObserver) {
                    window._sidebarObserver = new MutationObserver(() => {
                        createToolbar();
                        refreshCheckboxes();
                    });
                    window._sidebarObserver.observe(sidebarNav, { childList: true, subtree: true });
                }
            }
        });

        bodyObserver.observe(document.body, { childList: true, subtree: true });
        
        createToolbar();
        refreshCheckboxes();
        updateDeleteCounter();
    });
}

window.BulkUI = {
    init: initUI,
    setBulkMode: setBulkMode,
    updateProgress: (current, total) => {
        const bar = document.getElementById('bulk-progress-bar');
        const fill = document.getElementById('bulk-progress-fill');
        if (bar && fill) {
            bar.style.display = 'block';
            const percent = (current / total) * 100;
            fill.style.width = `${percent}%`;
            if (current === total) {
                setTimeout(() => { bar.style.display = 'none'; }, 2000);
            }
        }
    },
    showToast: (message, duration = 2500) => {
        const existing = document.querySelector('.bulk-toast');
        if (existing) existing.remove();
        const toast = document.createElement('div');
        toast.className = 'bulk-toast';
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), duration);
    }
};
