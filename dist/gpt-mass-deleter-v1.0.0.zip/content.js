(function() {
    console.log("[Bulk Manager] Content script loaded");

    function showModal(message) {
        return new Promise((resolve) => {
            const overlay = document.createElement("div");
            overlay.className = "bulk-modal-overlay";
            overlay.innerHTML = `
                <div class="bulk-modal-content">
                    <p style="margin-bottom: 20px; font-size: 16px;">${message}</p>
                    <div class="bulk-modal-buttons">
                        <button id="bulk-modal-yes" class="bulk-modal-btn bulk-modal-btn-yes">Confirm</button>
                        <button id="bulk-modal-no" class="bulk-modal-btn bulk-modal-btn-no">Cancel</button>
                    </div>
                </div>
            `;

            document.body.appendChild(overlay);

            overlay.querySelector("#bulk-modal-yes").onclick = () => {
                overlay.remove();
                resolve(true);
            };

            overlay.querySelector("#bulk-modal-no").onclick = () => {
                overlay.remove();
                resolve(false);
            };
        });
    }

    function showToast(msg) {
        const el = document.createElement("div");
        el.className = "bulk-toast";
        el.textContent = msg;
        document.body.appendChild(el);
        setTimeout(() => {
            el.style.opacity = '0';
            el.style.transition = 'opacity 0.5s ease';
            setTimeout(() => el.remove(), 500);
        }, 3000);
    }

    function getSelectedIds() {
        return Array.from(document.querySelectorAll('.bulk-checkbox:checked'))
            .map(cb => cb.dataset.chatId);
    }

    async function handleBulkAction(actionType) {
        const ids = getSelectedIds();
        if (ids.length === 0) {
            showToast("Please select at least one chat.");
            return;
        }

        const confirmed = await showModal(`${actionType.charAt(0).toUpperCase() + actionType.slice(1)} ${ids.length} chats?`);
        if (!confirmed) return;

        // Disable UI during processing
        document.querySelectorAll('.bulk-btn').forEach(btn => btn.disabled = true);

        const result = await window.BulkEngine.processBatch(ids, actionType, (current, total) => {
            window.BulkUI.updateProgress(current, total);
        });

        // Show limit modal if limit was reached
        if (result.limitReached) {
            const limitModal = document.getElementById('bulk-limit-modal');
            if (limitModal) {
                limitModal.style.display = 'flex';
            }
        } else {
            showToast(`Finished: ${result.successCount} succeeded, ${result.failCount} failed.`);
        }
        
        // Reset UI
        document.querySelectorAll('.bulk-checkbox').forEach(cb => cb.checked = false);
        document.querySelectorAll('.bulk-btn').forEach(btn => btn.disabled = false);
        document.getElementById('bulk-select-count').textContent = "0 selected";
    }

    // Initialize UI and attach listeners
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => window.BulkUI.init());
    } else {
        window.BulkUI.init();
    }

    document.addEventListener('change', e => {
        if (e.target.id === 'bulk-toggle') {
            window.BulkUI.setBulkMode(e.target.checked);
        }
    });

    document.addEventListener('click', e => {
        const limitModal = document.getElementById('bulk-limit-modal');
        
        if (e.target.id === 'bulk-select-all') {
            if (limitModal) limitModal.style.display = 'none';
            const allCheckboxes = document.querySelectorAll('.bulk-checkbox');
            const someUnchecked = Array.from(allCheckboxes).some(cb => !cb.checked);
            allCheckboxes.forEach(cb => cb.checked = someUnchecked);
            
            e.target.textContent = someUnchecked ? "Deselect All" : "Select All";
            const countEl = document.getElementById('bulk-select-count');
            countEl.textContent = `${someUnchecked ? allCheckboxes.length : 0} selected`;
        }
        
        if (e.target.id === 'bulk-delete-btn') {
            // Proceed with delete (backend will enforce limit)
            handleBulkAction('delete');
        }
        
        if (e.target.id === 'bulk-archive-btn') {
            if (limitModal) limitModal.style.display = 'none';
            handleBulkAction('archive');
        }
    });

})();
